import 'package:flutter/material.dart';
import 'package:LIB_Flutter/Home.dart';
import 'package:LIB_Flutter/Login.dart';
import 'package:LIB_Flutter/Splash.dart';
import 'package:LIB_Flutter/Register.dart';
import 'package:LIB_Flutter/profile.dart';

void main() {
  runApp(new MaterialApp(
    home: new Splash(),
    routes: <String, WidgetBuilder>{
      '/Register': (BuildContext context) => new Register(),
      '/Login': (BuildContext context) => new Login(),
      '/Home': (BuildContext context) => new Home(),
      '/Profile': (BuildContext context) => new Profile(),
    },
  ));
}
